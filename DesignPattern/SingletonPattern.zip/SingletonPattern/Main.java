package SingletonPattern;

public class Main {

	public static void main(String[] args) {
		Student s1 = Student.getStudent("Rafi","30",23,3.88);
		Student s2 = Student.getStudent("Messi","30",23,3.88);
		System.out.println(s2);
		

	}

}
