package CommandPattern;

public interface Command {
	public void execute();
}


class TubeLightOnCommand implements Command{
	Tubelight tubelight;
	TubeLightOnCommand(Tubelight tubelight){
		this.tubelight = tubelight;
	}
	@Override
	public void execute() {
		tubelight.switchOn();
	}	
}

class TubeLightOffCommand implements Command{
	Tubelight tubelight;
	TubeLightOffCommand(Tubelight tubelight){
		this.tubelight = tubelight;
	}
	@Override
	public void execute() {
		tubelight.switchOff();
	}
	
}

