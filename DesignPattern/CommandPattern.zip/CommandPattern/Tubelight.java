package CommandPattern;

public class Tubelight {
	
	public void switchOn() {
		System.out.println("Tubelight in on.");
	}
	
	public void switchOff() {
		System.out.println("Tubelight is off.");
	}
}
