package CommandPattern;

public class Client {

	public static void main(String[] args) {
		Tubelight a = new Tubelight();
		Command on = new TubeLightOnCommand(a);
		Command off = new TubeLightOffCommand(a);
		RemoteController x = new RemoteController(on);
		x.pressButton();
		x.setCommand(off);
		x.pressButton();
		

	}

}
