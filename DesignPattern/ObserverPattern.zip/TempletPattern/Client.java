package TempletPattern;

public class Client {

	public static void main(String[] args) {
		HouseBuilder khanBhaban = new WoodenHouse();
		khanBhaban.buildHouse();
		HouseBuilder NoorPalace = new GlassHouse();
		NoorPalace.buildHouse();
	}

}
