package TempletPattern;

public abstract class HouseBuilder {
	
	public void buildHouse() {
		createFoundation();
		buildPiller();
		buildRoof();
		createWalls();
	}
	
	public void createFoundation() {
		System.out.println("The foundation is created with rod,ciment,grit!");
	}
	
	public void buildPiller() {
		System.out.println("The piller is built.");
	}
	
	public abstract void buildRoof();
	public abstract void createWalls();
	
}


class WoodenHouse extends HouseBuilder{

	@Override
	public void buildRoof() {
		System.out.println("The roof is build with wood.");
	}

	@Override
	public void createWalls() {
		System.out.println("The walls are made of woods.");
	}
	
}


class GlassHouse extends HouseBuilder{

	@Override
	public void buildRoof() {
		System.out.println("The roof is build with glass.");
	}

	@Override
	public void createWalls() {
		System.out.println("The walls are made of glasses.");
	}
	
}

