package ObserverPattern;

public interface Observer {
	public void update(String msg);

}


class user1 implements Observer{

	@Override
	public void update(String msg) {
		System.out.println(msg+ " is received by user1");
	}
	
}

class user2 implements Observer{

	@Override
	public void update(String msg) {
		System.out.println(msg+ " is received by User2");
	}
	
}
class user3 implements Observer{

	@Override
	public void update(String msg) {
		System.out.println(msg+ " is received by User3");
	}
	
}
