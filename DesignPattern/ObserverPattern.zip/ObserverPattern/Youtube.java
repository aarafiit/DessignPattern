package ObserverPattern;

import java.util.ArrayList;

public interface Youtube {
	public void register(Observer o);
	public void unregister(Observer o);
	public void sendNotification(String msg);

}


class Youtubechannel1 implements Youtube{
	
	ArrayList<Observer> observers;
	
	Youtubechannel1(){
		observers = new ArrayList<Observer>();
	}

	@Override
	public void register(Observer o) {
		observers.add(o);
		
	}

	@Override
	public void unregister(Observer o) {
		observers.remove(o);
		
	}

	@Override
	public void sendNotification(String msg) {
		for(Observer o : observers) {
			o.update(msg);
		}
		
	}
	
}