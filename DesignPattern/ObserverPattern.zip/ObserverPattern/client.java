package ObserverPattern;

public class client {

	public static void main(String[] args) {
		Youtube bbkivines = new Youtubechannel1();
		Youtube threebrown1blue = new Youtubechannel1();
		
		Observer a = new user1();
		Observer b = new user2();
		
		
		bbkivines.register(a);
		bbkivines.register(b);
		bbkivines.sendNotification("Hello");
		bbkivines.unregister(b);
		bbkivines.sendNotification("Hooooo");
		

	}

}
