package ChainOfResponsibility;

public interface IEmailHandler {
	public void nextHandler(IEmailHandler next);
	public void handle (Email email);

}








