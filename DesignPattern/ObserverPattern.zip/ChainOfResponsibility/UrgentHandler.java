package ChainOfResponsibility;

public class UrgentHandler implements IEmailHandler{
	
	private IEmailHandler next;

	@Override
	public void nextHandler(IEmailHandler next) {
		this.next = next;
	}

	@Override
	public void handle(Email email) {
		if(email.getPriority() >= 2) {
			System.out.println("Subject : "+ email.getSubject() + "\n Body : "+email.getBody() + "\n is an urgent email.");
		}
		else if(next != null) {
			next.handle(email);
		}
		
	}
	
}

