package SingletonPattern;

public class Student {
	
	private static Student student;
	private String name;
	private String id;
	private int age;
	private double gpa;
	
	private Student(String name,String id,int age,double gpa) {
		this.age = age;
		this.gpa = gpa;
		this.id = id;
		this.name = name;
	}
	
	public String toString() {
		return Student.student.name;
	}
	
	public static Student getStudent(String name,String id,int age,double gpa) {
		if(Student.student == null) {
			Student.student =  new Student(name,id,age,gpa);
		}
		return student;
	}

}
