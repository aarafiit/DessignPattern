package MediatorPattern2;

public abstract class Buyer {
	
	protected String buyerName;
	protected double biddingPrice;
	protected Mediator mediator;
	
	Buyer(Mediator mediator,String buyerName){
		this.mediator = mediator;
		this.buyerName = buyerName;
	}
	
	
	
	
	public String getBuyerName() {
		return buyerName;
	}
	public double getBiddingPrice() {
		return biddingPrice;
	}
	public Mediator getMediator() {
		return mediator;
	}
	
	
	
	
	public abstract void  bid(double biddingPrice);
	
	public void receiveMessage(String message) {
        System.out.println(message);
    }

}

class AmericanBuyer extends Buyer{
	
	private String buyerName;
	private double biddingPrice;
	private Mediator mediator;
	
	
	
	
	public String getBuyerName() {
		return buyerName;
	}
	public double getBiddingPrice() {
		return biddingPrice;
	}
	public Mediator getMediator() {
		return mediator;
	}
	
	AmericanBuyer(Mediator mediator,String buyerName){
		super(mediator,buyerName);
		this.buyerName = buyerName;
		this.mediator = mediator;
		
	}

	@Override
	public void bid(double biddingPrice) {
		this.biddingPrice = biddingPrice*100;
		System.out.println(this.getBuyerName() + " bids for "+ this.biddingPrice + " Tk.");
		//mediator.findWinner();
	}
	
}


class IndianBuyer extends Buyer{
	
	private String buyerName;
	private double biddingPrice;
	private Mediator mediator;
	
	
	
	
	public String getBuyerName() {
		return buyerName;
	}
	public double getBiddingPrice() {
		return biddingPrice;
	}
	public Mediator getMediator() {
		return mediator;
	}
	
	IndianBuyer(Mediator mediator,String buyerName){
		super(mediator,buyerName);
		this.buyerName = buyerName;
		this.mediator = mediator;
		
	}

	@Override
	public void bid(double biddingPrice) {
		this.biddingPrice = biddingPrice*1.25;
		System.out.println(this.getBuyerName() + " bids for "+ this.biddingPrice + " Tk.");	
		//mediator.findWinner();
	}
	
	
	
}


class BangladeshiBuyer extends Buyer{
	
	private String buyerName;
	private double biddingPrice;
	private Mediator mediator;
	
	
	
	
	public String getBuyerName() {
		return buyerName;
	}
	public double getBiddingPrice() {
		return biddingPrice;
	}
	public Mediator getMediator() {
		return mediator;
	}
	
	BangladeshiBuyer(Mediator mediator,String buyerName){
		super(mediator,buyerName);
		this.buyerName = buyerName;
		this.mediator = mediator;
		
	}

	@Override
	public void bid(double biddingPrice) {
		this.biddingPrice = biddingPrice;
		System.out.println(this.getBuyerName() + " bids for "+ this.biddingPrice + " Tk.");
		//mediator.findWinner();
	}
	
}
