package MediatorPattern;

public abstract class User {
	
	private String userName;
	private ChattingMediator chattingMediator;
	
	User(ChattingMediator chattingMediator,String userName){
		this.chattingMediator = chattingMediator;
		this.userName = userName;
	}

//	public ChattingMediator getChattingMediator() {
//		return chattingMediator;
//	}

	public String getUserName() {
		return this.userName;
	}
	
	
	public abstract void sendMsg(String msg);
	public abstract void receiveMsg(String msg);

}


class UserImpl extends User{
	
	private String userName;
	private ChattingMediator chattingMediator;
	//private User x;
	public UserImpl(ChattingMediator chattingMediator, String userName) {
		super(chattingMediator, userName);
		this.chattingMediator = chattingMediator;
		this.userName = userName;
		
	}

	@Override
	public void sendMsg(String msg) {
		System.out.println(this.userName + " sending message " + msg);
		this.chattingMediator.sendMessage(msg, this);
		
	}

	@Override
	public void receiveMsg(String msg) {
		System.out.println(this.userName + " received message " + msg);
		
	}
	
}
