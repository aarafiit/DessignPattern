package MediatorPattern;

public class Client {

	public static void main(String[] args) {
		ChattingMediator pompom = new ChattingMediatorImpl();
		
		User u1 = new UserImpl(pompom,"Rafi");
		User u2 = new UserImpl(pompom,"Rocket");
		User u3 = new UserImpl(pompom,"Mamun");
		User u4 = new UserImpl(pompom,"Tahsin");
		
		pompom.addUser(u1);
		pompom.addUser(u2);
		pompom.addUser(u3);
		pompom.addUser(u4);
		
		u1.sendMsg("Link de,mama");
		u2.sendMsg("Wait kor 2 min");
	}

}
