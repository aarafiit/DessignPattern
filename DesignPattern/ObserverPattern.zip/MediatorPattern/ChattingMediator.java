package MediatorPattern;

import java.util.List;
import java.util.ArrayList;
public interface ChattingMediator {
	public void sendMessage(String msg,User user);
	public void addUser(User user);
}


class ChattingMediatorImpl implements ChattingMediator{
	
	List<User> users;
	ChattingMediatorImpl(){
		users = new ArrayList<User>();
	}
	
	@Override
	public void sendMessage(String msg, User user) {
		for(User u : users) {
			if(!u.getUserName().equalsIgnoreCase(user.getUserName())) {
				u.receiveMsg(msg);
			}
		}
	}

	@Override
	public void addUser(User user) {
		System.out.println(user.getUserName() + " is added");
		users.add(user);
	}
	
}
