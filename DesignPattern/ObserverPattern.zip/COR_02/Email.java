package COR_02;

public class Email {
		private int id;
		private String msg;
		private String priority;
		
		Email(int id,String msg,String priority){
			this.id = id;
			this.msg = msg;
			this.priority = priority;
		}

		public int getId() {
			return id;
		}

		public String getMsg() {
			return msg;
		}

		public String getPriority() {
			return priority;
		}
		
		
}
