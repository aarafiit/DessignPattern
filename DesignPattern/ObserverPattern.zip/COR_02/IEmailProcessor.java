package COR_02;

public interface IEmailProcessor {
	public void processEmail(Email email);
}


class BoardProcessor implements IEmailProcessor{
	IEmailProcessor next;
	BoardProcessor(IEmailProcessor next){
		this.next = next;
	}
	
	
	@Override
	public void processEmail(Email email) {
		if(email.getPriority() == "High" || email.getPriority() == "Medium" || email.getPriority() == "Low") {
			System.out.println("Email " + email.getId() + " is processed by Board.");
		}
		else if(next != null) {
			next.processEmail(email);
		}
		else {
			System.out.println("Email " + email.getId() + " can't be processed.");
		}
		
	}
	
}


class CoachProcessor implements IEmailProcessor{
	IEmailProcessor next;
	CoachProcessor(IEmailProcessor next){
		this.next = next;
	}
	
	
	@Override
	public void processEmail(Email email) {
		if( email.getPriority() == "Medium" ) {
			System.out.println("Email " + email.getId() + " is processed by Coach.");
		}
		else if(next != null) {
			next.processEmail(email);
		}
		else {
			System.out.println("Email " + email.getId() + " can't be processed.");
		}
		
	}
	
}


class CaptainProcessor implements IEmailProcessor{
	IEmailProcessor next;
	CaptainProcessor(IEmailProcessor next){
		this.next = next;
	}
	
	
	@Override
	public void processEmail(Email email) {
		if( email.getPriority() == "Low" ) {
			System.out.println("Email " + email.getId() + " is processed by Captain.");
		}
		else if(next != null) {
			next.processEmail(email);
		}
		else {
			System.out.println("Email " + email.getId() + " can't be processed.");
		}
	}
	
}
