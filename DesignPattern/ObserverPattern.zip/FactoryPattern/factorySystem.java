package FactoryPattern;

public class factorySystem {
	
	Payment getFactorySystem(String str){
		if(str.equals("Bkash")) return new Bkash();
		if(str.equals("Nagad")) return new Nagad();
		if(str.equals("Rocket")) return new Rocket();
		return  new nullHandler();
		
	}

}



