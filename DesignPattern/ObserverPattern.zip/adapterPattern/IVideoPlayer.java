package adapterPattern;

public interface IVideoPlayer {
	public void playAudio(String file);
	public void playVideo(String file);
}

class Mp4Player implements IVideoPlayer{

	@Override
	public void playAudio(String file) {
		System.out.println(file + " audio played by MP4");
		
	}

	@Override
	public void playVideo(String file) {
		System.out.println(file + " video played by MP4.");
		
	}
	
}


class AVIPlayer implements IVideoPlayer{

	@Override
	public void playAudio(String file) {
		System.out.println(file + " audio played by AVI.");
	}

	@Override
	public void playVideo(String file) {
		System.out.println(file + " audio played by AVI.");
	}
	
}

class Adapter implements IVideoPlayer{
	MP3Player mp3 = new MP3Player();
	@Override
	public void playAudio(String file) {
		mp3.play(file);
	}

	@Override
	public void playVideo(String file) {
		System.out.println(file + " video played randomly.");
		
	}
	
}







