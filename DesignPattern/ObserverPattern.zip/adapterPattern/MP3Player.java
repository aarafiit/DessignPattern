package adapterPattern;

public class MP3Player {
	
	public void play(String file) {
		System.out.println(file + " audio is played by MP3.");
	}

}
