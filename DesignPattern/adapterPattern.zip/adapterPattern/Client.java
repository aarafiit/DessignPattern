package adapterPattern;

public class Client {

	public static void main(String[] args) {
		MediaPlayer mp = new MediaPlayer();
		mp.play("Game_of_thrones_theme_song.mp3");
		System.out.println();
		mp.play("Game_of_thrones_season_8_trailer.mp4");
		System.out.println();
		mp.play("Game_of_thrones_season_8_trailer.avi");
	}

}
