package adapterPattern;

public class MediaPlayer {
	
	IVideoPlayer vp;
	
	public void play(String file) {
		vp = CreatePlayer(file);
		vp.playAudio(file);
		vp.playVideo(file);
	}
	
	IVideoPlayer CreatePlayer(String file) {
		String[] newString = file.split("\\.");
		String extension = newString[1];
		
		if(extension.equalsIgnoreCase("mp3")) {
			return new Adapter();
		}
		else if(extension.equalsIgnoreCase("mp4")) {
			return new Mp4Player();
		}
		else if(extension.equalsIgnoreCase("avi")) {
			return new AVIPlayer();
		}
		return null;
	}

}
