package COR_02;

public class Main {

	public static void main(String[] args) {
		Email a = new Email(121,"Who is the opener batsman?","Low");
		Email b = new Email(123,"What will we choose after winning the toss?","Medium");
		Email c = new Email(125,"Will BD participate in the SL series?","High");
		
		
		IEmailProcessor ep1 = new CaptainProcessor(new CoachProcessor(new BoardProcessor(null)));
		IEmailProcessor ep2 = new CoachProcessor(null);
		ep1.processEmail(a);
		ep1.processEmail(b);
		ep1.processEmail(c);
		
		ep2.processEmail(a);
		ep2.processEmail(b);
		ep2.processEmail(c);
	}

}
