package MediatorPattern2;

import java.util.List;
import java.util.ArrayList;

public interface Mediator {
	
	public void addBuyer(Buyer buyer);
	public void findWinner();
	

}

class AuctionMediator implements Mediator{
	
	List<Buyer> buyers;
	
	AuctionMediator(){
		this.buyers = new ArrayList<Buyer>();
	}
	
	@Override
	public void addBuyer(Buyer buyer) {
		System.out.println(buyer.getBuyerName() + " has been added successfully");
		buyers.add(buyer);
		
	}

	@Override
	public void findWinner() {
		double max = 0.00;
		Buyer winner = null;
		for(Buyer b:buyers) {
			if(b.getBiddingPrice() > max) {
				max = b.getBiddingPrice();
				winner = b;
			}
		}
		
		for(Buyer b : buyers) {
			if(b.equals(winner)) {
				System.out.println("The auction winnwer is " + winner.getBuyerName());
			}
			else {
				b.receiveMessage("The auction is over. Received by " + b.getBuyerName());
				//System.out.println("The auction is over. Received by " + b.getBuyerName());
			}
		}
		
	}

	
	
}


