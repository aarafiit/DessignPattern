package MediatorPattern2;

public class Main {

	public static void main(String[] args) {
		Mediator mediator = new AuctionMediator();
		Buyer b1 = new AmericanBuyer(mediator,"Elon mask");
		Buyer b2 = new BangladeshiBuyer(mediator,"Shakib Al Hasan");
		Buyer b3 = new IndianBuyer(mediator,"Virat Kohli");
		
		mediator.addBuyer(b1);
		mediator.addBuyer(b2);
		mediator.addBuyer(b3);
		
		
		
		b1.bid(1500.00);
		b2.bid(9000.00);
		b3.bid(5000.00);
		
		
		mediator.findWinner();
		

	}

}
