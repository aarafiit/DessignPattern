package FactoryPattern;

public interface Payment {
	public void pay(int amount);
}


class Bkash implements Payment{

	@Override
	public void pay(int amount) {
		System.out.println("Welcome to bkash");
		System.out.println(amount + "Tk is paid through Bkash");
		
	}
	
}


class Rocket implements Payment{

	@Override
	public void pay(int amount) {
		
		System.out.println("Welcome to Rocket");
		System.out.println(amount + "Tk is paid through Rocket");
	}
	
}



class Nagad implements Payment{

	@Override
	public void pay(int amount) {
		
		System.out.println("Welcome to Nagad");
		System.out.println(amount + "Tk is paid through Nagad");
	}
	
}


class nullHandler implements Payment{

	@Override
	public void pay(int amount) {
		System.out.println("Sorry");
		
	}
	 
}

