package FactoryPattern;

import java.util.*;

public class Client {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		String param = input.nextLine();
		factorySystem test = new factorySystem();
		Payment payment = test.getFactorySystem(param);
		payment.pay(500);
		

	}

}
