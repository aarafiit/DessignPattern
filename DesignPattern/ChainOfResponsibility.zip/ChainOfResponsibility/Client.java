package ChainOfResponsibility;

public class Client {
	public static void main(String[] args) {
		Email e1 = new Email("Birthday wish","Happy birthday to U!",2);
		Email e2 = new Email("Birthday wish","Happy birthday to U!",3);
		
		IEmailHandler general = new GeneralHandler();
		IEmailHandler urgent = new UrgentHandler();
		IEmailHandler spam = new SpamHandler();
		
		
		// Chain of responsibility
		
		spam.nextHandler(general);
		general.nextHandler(urgent);
		
		spam.handle(e1);
		spam.handle(e2);
		
	}
}
