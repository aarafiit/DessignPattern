package ChainOfResponsibility;

public class SpamHandler implements IEmailHandler{
	
	private IEmailHandler next;

	@Override
	public void nextHandler(IEmailHandler next) {
		this.next = next;
	}

	@Override
	public void handle(Email email) {
		if(email.getPriority() >= 3) {
			System.out.println("Subject : "+ email.getSubject() + "\n Body : "+email.getBody() + "\n is a spam email.");
		}
		else if(next != null) {
			next.handle(email);
		}
		
	}
	
}
