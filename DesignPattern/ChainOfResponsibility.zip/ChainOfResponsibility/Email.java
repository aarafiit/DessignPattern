package ChainOfResponsibility;

public class Email {
	
	private String subject;
	private String body;
	private int priority;
	
	Email(String subject,String body,int priority){
		this.subject = subject;
		this.body = body;
		this.priority = priority;
	}

	public String getSubject() {
		return subject;
	}

	public String getBody() {
		return body;
	}

	public int getPriority() {
		return priority;
	}
	
	

}
