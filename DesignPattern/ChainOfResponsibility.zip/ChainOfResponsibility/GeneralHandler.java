package ChainOfResponsibility;

public class GeneralHandler implements IEmailHandler{
	
	private IEmailHandler next;

	@Override
	public void nextHandler(IEmailHandler next) {
		this.next = next;
	}

	@Override
	public void handle(Email email) {
		if(email.getPriority() >= 1) {
			System.out.println("Subject : "+ email.getSubject() + "\n Body : "+email.getBody() + "\n is a general email.");
		}
		else if(next != null) {
			next.handle(email);
		}
		
	}
	
}

